// ─── Gridline Digital · Maps Scraper · Popup v2 ──────────────────────────────
(function () {
  'use strict';

  let allLeads = [];
  let filteredLeads = [];
  let scraping = false;
  let lastCount = 0;

  // Pending import data (set during preflight, used on confirm)
  let pendingImport = null;   // { toImport, dupes, token, spreadsheetId }

  const $ = id => document.getElementById(id);

  // ── Init ────────────────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    loadLeads();
    setupListeners();
    setInterval(pollLeads, 800);
    checkCurrentTab();
    loadSettings();
  });

  // ── Tab check ───────────────────────────────────────────────────────────────
  function checkCurrentTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab || !tab.url?.includes('google.com/maps')) {
        setStatus('⚠ Open Google Maps and search for businesses', false);
        $('btnStart').disabled = true;
        $('btnNow').disabled = true;
      } else {
        chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (res) => {
          if (res?.scraping) { scraping = true; setScraping(true); }
        });
      }
    });
  }

  // ── Lead loading ─────────────────────────────────────────────────────────────
  function loadLeads() {
    chrome.runtime.sendMessage({ type: 'GET_LEADS' }, (res) => {
      if (res?.leads) { allLeads = res.leads; applyFilters(); }
    });
  }

  function pollLeads() {
    chrome.runtime.sendMessage({ type: 'GET_LEADS' }, (res) => {
      if (res?.leads && res.leads.length !== lastCount) {
        lastCount = res.leads.length;
        allLeads = res.leads;
        applyFilters();
        if (scraping) setStatus(`Scraping… ${allLeads.length} leads collected`, true);
      }
    });
  }

  // ── Settings ─────────────────────────────────────────────────────────────────
  function loadSettings() {
    chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (res) => {
      const id = res?.spreadsheetId || '';
      $('inputSheetId').value = id;
      updateSheetStrip(id);
    });
  }

  function saveSettings() {
    const id = $('inputSheetId').value.trim();
    chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', spreadsheetId: id }, () => {
      updateSheetStrip(id);
      showFeedback($('sheetValidation'), '✓ Settings saved', 'ok');
    });
  }

  function updateSheetStrip(sheetId) {
    if (sheetId) {
      $('sheetStripText').textContent = `Connected to spreadsheet`;
      $('sheetStripOpen').style.display = 'block';
      $('sheetStripOpen').onclick = () => {
        chrome.tabs.create({ url: `https://docs.google.com/spreadsheets/d/${sheetId}/edit` });
      };
      $('btnSheets').disabled = false;
    } else {
      $('sheetStripText').textContent = 'No spreadsheet configured — open Settings to connect';
      $('sheetStripOpen').style.display = 'none';
      $('btnSheets').disabled = false; // still let them click — will prompt
    }
  }

  function showFeedback(el, msg, type) {
    el.textContent = msg;
    el.className = 'settings-feedback ' + type;
    if (type === 'ok') setTimeout(() => { el.textContent = ''; el.className = 'settings-feedback'; }, 3000);
  }

  // ── Validate spreadsheet ─────────────────────────────────────────────────────
  async function validateSheet() {
    const id = $('inputSheetId').value.trim();
    if (!id) { showFeedback($('sheetValidation'), 'Please enter a Spreadsheet ID first.', 'err'); return; }
    showFeedback($('sheetValidation'), 'Verifying…', 'checking');
    try {
      const result = await SHEETS.validateSpreadsheet(id);
      if (result.valid) {
        showFeedback($('sheetValidation'), `✓ Connected: "${result.title}"`, 'ok');
      } else {
        showFeedback($('sheetValidation'), `✗ ${result.error}`, 'err');
      }
    } catch (e) {
      showFeedback($('sheetValidation'), `✗ ${e.message}`, 'err');
    }
  }

  // ── Views ────────────────────────────────────────────────────────────────────
  function showView(name) {
    $('mainView').style.display    = name === 'main'     ? 'flex'   : 'none';
    $('settingsView').style.display = name === 'settings' ? 'flex'   : 'none';
    if (name === 'main') {
      $('mainView').style.flexDirection = 'column';
      $('mainView').style.flex = '1';
    }
  }

  // ── Sheets: Push to Sheets flow ──────────────────────────────────────────────
  async function pushToSheets() {
    if (!allLeads.length) {
      alert('No leads to export yet. Scrape some leads first!');
      return;
    }
    if (!filteredLeads.length) {
      alert('No leads match your current filters. Adjust the filters and try again.');
      return;
    }

    // Get configured sheet ID
    const settings = await new Promise(res =>
      chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, res));
    const spreadsheetId = settings?.spreadsheetId?.trim();

    if (!spreadsheetId) {
      alert('No Spreadsheet ID configured.\n\nOpen Settings (gear icon) and paste your Google Sheet ID.');
      showView('settings');
      return;
    }

    showOverlay('Connecting to Google Sheets…');

    try {
      // Run preflight using FILTERED leads only
      showOverlay(`Checking ${filteredLeads.length} filtered leads for duplicates…`);
      const result = await SHEETS.exportToSheets(filteredLeads, spreadsheetId);
      hideOverlay();

      // Store pending import
      pendingImport = result;

      // Show filter context above stats
      const wf = document.querySelector('input[name="websiteFilter"]:checked')?.value || 'all';
      const hasPhone = $('filterHasPhone').checked;
      const hasAddr  = $('filterHasAddress').checked;
      const filterTags = [];
      if (wf === 'none_or_social') filterTags.push('No real website');
      if (wf === 'none')           filterTags.push('No website');
      if (wf === 'social')         filterTags.push('Social only');
      if (hasPhone)  filterTags.push('Has phone');
      if (hasAddr)   filterTags.push('Has address');
      const ratingEl = $('filterRating');
      if (ratingEl.value) filterTags.push(`${ratingEl.value}★+`);
      const searchVal = $('filterSearch').value.trim();
      if (searchVal) filterTags.push(`"${searchVal}"`);

      const filterCtx = $('modalFilterContext');
      if (filterTags.length) {
        filterCtx.innerHTML = 'Importing leads matching: ' + filterTags.map(t =>
          `<span class="filter-tag">${t}</span>`).join(' ');
        filterCtx.style.display = 'block';
      } else {
        filterCtx.style.display = 'none';
      }

      // Populate modal
      $('modalImportCount').textContent = result.toImport.length;
      $('modalDupeCount').textContent   = result.dupes.length;

      if (result.dupes.length > 0) {
        $('modalDupeList').style.display = 'block';
        $('modalDupeScroll').innerHTML = result.dupes.map(d =>
          `<div class="dupe-item">
            <span class="dupe-item-name">${esc(d.name)}</span>
            <span class="dupe-item-phone">${esc(d.phone || 'no phone')}</span>
          </div>`
        ).join('');
      } else {
        $('modalDupeList').style.display = 'none';
      }

      if (result.toImport.length === 0) {
        $('modalNoImport').style.display = 'block';
        $('btnConfirmImport').disabled = true;
      } else {
        $('modalNoImport').style.display = 'none';
        $('btnConfirmImport').disabled = false;
      }

      $('importModal').style.display = 'flex';

    } catch (e) {
      hideOverlay();
      alert(`Sheets error: ${e.message}\n\nCheck your Spreadsheet ID and Google Cloud setup.`);
    }
  }

  async function confirmImport() {
    if (!pendingImport) return;
    const sheetId = pendingImport.spreadsheetId;
    const token   = pendingImport.token;
    const toImport = pendingImport.toImport;
    closeModal();
    showOverlay('Writing to Google Sheets…');

    try {
      const { imported, sheetName } = await SHEETS.commitImport(toImport, sheetId, token);
      hideOverlay();
      pendingImport = null;
      updateSheetStrip(sheetId);
      setStatus(`✓ ${imported} lead${imported !== 1 ? 's' : ''} pushed to Sheets → tab "${sheetName}"`, false);
    } catch (e) {
      hideOverlay();
      alert(`Import failed: ${e.message}`);
    }
  }

  function closeModal() {
    $('importModal').style.display = 'none';
  }

  function showOverlay(msg) {
    $('sheetsOverlayText').textContent = msg;
    $('sheetsOverlay').style.display = 'flex';
  }

  function hideOverlay() {
    $('sheetsOverlay').style.display = 'none';
  }

  // ── Event listeners ───────────────────────────────────────────────────────────
  function setupListeners() {
    // Scraper
    $('btnStart').addEventListener('click', startScraping);
    $('btnStop').addEventListener('click', stopScraping);
    $('btnNow').addEventListener('click', grabNow);

    // Export
    $('btnCSV').addEventListener('click', exportCSV);
    $('btnCopy').addEventListener('click', exportJSON);
    $('btnClear').addEventListener('click', clearLeads);

    // Sheets
    $('btnSheets').addEventListener('click', pushToSheets);
    $('btnConfirmImport').addEventListener('click', confirmImport);
    $('btnCancelImport').addEventListener('click', closeModal);
    $('btnCloseModal').addEventListener('click', closeModal);

    // Settings
    $('btnSettings').addEventListener('click', () => {
      loadSettings();
      showView('settings');
    });
    $('btnBackFromSettings').addEventListener('click', () => showView('main'));
    $('btnSaveSettings').addEventListener('click', saveSettings);
    $('btnValidateSheet').addEventListener('click', validateSheet);
    $('btnDisconnectGoogle').addEventListener('click', async () => {
      await SHEETS.revokeToken();
      showFeedback($('sheetValidation'), '✓ Google account disconnected', 'ok');
    });

    // Filters
    $('filterSearch').addEventListener('input', applyFilters);
    $('filterRating').addEventListener('change', applyFilters);
    $('filterHasPhone').addEventListener('change', applyFilters);
    $('filterHasAddress').addEventListener('change', applyFilters);
    document.querySelectorAll('input[name="websiteFilter"]').forEach(r =>
      r.addEventListener('change', applyFilters));
  }

  // ── Scraping ──────────────────────────────────────────────────────────────────
  function startScraping() {
    const limitVal = parseInt($('leadLimit').value, 10);
    const limit = (!isNaN(limitVal) && limitVal > 0) ? limitVal : 0;
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { type: 'START_SCRAPING', limit }, () => {
        chrome.runtime.sendMessage({ type: 'SET_SCRAPING', value: true });
        scraping = true;
        setScraping(true);
        const limitMsg = limit ? ` (stops at ${limit})` : '';
        setStatus(`Clicking through each business to get phone numbers…${limitMsg}`, true);
      });
    });
  }

  function stopScraping() {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { type: 'STOP_SCRAPING' }, () => {
        chrome.runtime.sendMessage({ type: 'SET_SCRAPING', value: false });
        scraping = false;
        setScraping(false);
        setStatus(`Stopped — ${allLeads.length} leads collected`, false);
      });
    });
  }

  function grabNow() {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (!tab) return;
      chrome.tabs.sendMessage(tab.id, { type: 'SCRAPE_NOW' }, () => {
        setStatus('Grabbed current panel!', false);
        setTimeout(loadLeads, 600);
      });
    });
  }

  function setScraping(active) {
    $('btnStart').disabled = active;
    $('btnStop').disabled = !active;
    $('statusDot').className = 'status-dot' + (active ? ' active' : '');
  }

  function setStatus(text, active) {
    $('statusText').textContent = text;
    $('statusDot').className = 'status-dot' + (active ? ' active' : '');
  }

  // ── Filters ───────────────────────────────────────────────────────────────────
  function getWebsiteFilter() {
    return document.querySelector('input[name="websiteFilter"]:checked')?.value || 'all';
  }

  function applyFilters() {
    const search    = $('filterSearch').value.toLowerCase().trim();
    const minRating = parseFloat($('filterRating').value) || 0;
    const needPhone = $('filterHasPhone').checked;
    const needAddr  = $('filterHasAddress').checked;
    const webFilter = getWebsiteFilter();

    filteredLeads = allLeads.filter(lead => {
      if (search && !JSON.stringify(lead).toLowerCase().includes(search)) return false;
      if (minRating && parseFloat(lead.rating) < minRating) return false;
      if (needPhone && !lead.phone) return false;
      if (needAddr  && !lead.address) return false;
      const wt = lead.website_type || (lead.website ? 'real' : 'none');
      if (webFilter === 'none'         && wt !== 'none') return false;
      if (webFilter === 'social'       && wt !== 'social') return false;
      if (webFilter === 'none_or_social' && wt !== 'none' && wt !== 'social') return false;
      return true;
    });

    renderTable();
    $('leadCount').textContent = `${allLeads.length} lead${allLeads.length !== 1 ? 's' : ''}`;
  }

  // ── Table render ──────────────────────────────────────────────────────────────
  function renderTable() {
    const tbody = $('leadsBody');
    const table = $('leadsTable');
    const empty = $('emptyState');
    const total   = allLeads.length;
    const showing = filteredLeads.length;

    $('footerStats').textContent = showing === total
      ? `${total} lead${total !== 1 ? 's' : ''} collected`
      : `Showing ${showing} of ${total} leads`;

    if (showing === 0) {
      table.style.display = 'none';
      empty.style.display = 'flex';
      return;
    }
    table.style.display = 'table';
    empty.style.display = 'none';

    const display = filteredLeads.slice(-300).reverse();
    tbody.innerHTML = display.map((lead, i) => {
      const wt = lead.website_type || (lead.website ? 'real' : 'none');
      let websiteCell;
      if (lead.website) {
        const label = shortUrl(lead.website);
        const cls   = wt === 'social' ? 'website-social' : 'website-real';
        const tag   = wt === 'social' ? ' <span class="tag-social">social</span>' : '';
        websiteCell = `<a href="${esc(lead.website)}" target="_blank" class="${cls}" title="${esc(lead.website)}">${esc(label)}</a>${tag}`;
      } else {
        websiteCell = '<span class="tag-none">none</span>';
      }

      return `<tr class="${i === 0 ? 'row-new' : ''}">
        <td class="name"    title="${esc(lead.name)}">${esc(lead.name)}</td>
        <td class="phone">${esc(lead.phone || '—')}</td>
        <td class="website">${websiteCell}</td>
        <td class="rating">${lead.rating ? esc(String(lead.rating)) : '—'}</td>
        <td class="address" title="${esc(lead.address || '')}">${esc(lead.address || '—')}</td>
      </tr>`;
    }).join('');
  }

  // ── Utilities ─────────────────────────────────────────────────────────────────
  function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function shortUrl(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); }
    catch { return url.slice(0, 28); }
  }
  function ts() { return new Date().toISOString().replace(/[:.]/g,'-').slice(0,19); }

  // ── CSV / JSON export ─────────────────────────────────────────────────────────
  function exportCSV() {
    if (!filteredLeads.length) return alert('No leads to export!');
    const fields = ['placeUrl','title','rating','reviewCount','category','address','plusCode','website','phoneNumber','currentStatus'];
    const remap = lead => ({
      placeUrl:      lead.placeUrl     || (lead.place_id ? `https://www.google.com/maps/place/?q=place_id:${lead.place_id}` : ''),
      title:         lead.name         || '',
      rating:        lead.rating       || '',
      reviewCount:   lead.reviewCount  || '',
      category:      lead.category     || '',
      address:       lead.address      || '',
      plusCode:      lead.plusCode     || '',
      website:       lead.website      || '',
      phoneNumber:   lead.phone        || '',
      currentStatus: lead.currentStatus|| '',
    });
    const rows = filteredLeads.map(l => {
      const r = remap(l);
      return fields.map(f => `"${String(r[f]||'').replace(/"/g,'""')}"`).join(',');
    });
    download([fields.join(','), ...rows].join('\n'), `gridline_leads_${ts()}.csv`, 'text/csv');
  }

  function exportJSON() {
    if (!filteredLeads.length) return alert('No leads to export!');
    download(JSON.stringify(filteredLeads, null, 2), `gridline_leads_${ts()}.json`, 'application/json');
  }

  function download(content, filename, type) {
    const a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(new Blob([content], { type })),
      download: filename
    });
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function clearLeads() {
    if (!allLeads.length) return;
    if (!confirm(`Delete all ${allLeads.length} leads from local storage?`)) return;
    chrome.runtime.sendMessage({ type: 'CLEAR_LEADS' }, () => {
      allLeads = []; filteredLeads = []; lastCount = 0;
      renderTable();
      setStatus('Leads cleared. Ready to scrape.', false);
    });
  }

  // ── Background messages ───────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'SCROLL_DONE') {
      scraping = false; setScraping(false);
      setStatus(`✓ Done — ${allLeads.length} leads collected`, false);
      loadLeads();
    }
    if (msg.type === 'LIMIT_REACHED') {
      scraping = false; setScraping(false);
      setStatus(`✓ Limit reached — ${allLeads.length} leads collected`, false);
      loadLeads();
    }
    if (msg.type === 'STATUS_MSG') {
      setStatus(msg.msg, scraping);
    }
  });

})();
