// ─── Gridline Digital · Background Service Worker ────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ leads: [], scraping: false });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'GET_LEADS') {
    chrome.storage.local.get(['leads'], (data) => {
      sendResponse({ leads: data.leads || [] });
    });
    return true;
  }

  if (message.type === 'ADD_LEAD') {
    chrome.storage.local.get(['leads'], (data) => {
      const leads = data.leads || [];
      const lead = message.lead;
      const key = lead.place_id || (lead.name + '|' + (lead.address || ''));
      const exists = leads.some(l => {
        const lk = l.place_id || (l.name + '|' + (l.address || ''));
        return lk === key;
      });
      if (!exists) {
        leads.push({ ...lead, scraped_at: new Date().toISOString() });
        chrome.storage.local.set({ leads });
        sendResponse({ success: true, total: leads.length });
      } else {
        sendResponse({ success: false, duplicate: true });
      }
    });
    return true;
  }

  if (message.type === 'CLEAR_LEADS') {
    chrome.storage.local.set({ leads: [] });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'SET_SCRAPING') {
    chrome.storage.local.set({ scraping: message.value });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'GET_STATUS') {
    chrome.storage.local.get(['scraping'], (data) => {
      sendResponse({ scraping: data.scraping || false });
    });
    return true;
  }

  if (message.type === 'GET_SETTINGS') {
    chrome.storage.sync.get(['spreadsheetId'], (data) => {
      sendResponse({ spreadsheetId: data.spreadsheetId || '' });
    });
    return true;
  }

  if (message.type === 'SAVE_SETTINGS') {
    chrome.storage.sync.set({ spreadsheetId: message.spreadsheetId }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'SCROLL_DONE' || message.type === 'STATUS_MSG' || message.type === 'LIMIT_REACHED') {
    chrome.runtime.sendMessage(message).catch(() => {});
    return true;
  }
});
