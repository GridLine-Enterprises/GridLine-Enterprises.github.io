// ─── Gridline Digital · Google Sheets Integration ───────────────────────────
// Handles OAuth, reading existing data, duplicate detection, and writing.

const SHEETS = (() => {
  'use strict';

  // ── Auth ────────────────────────────────────────────────────────────────────
  async function getToken(interactive = true) {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(new Error(chrome.runtime.lastError?.message || 'Auth failed'));
        } else {
          resolve(token);
        }
      });
    });
  }

  async function revokeToken() {
    return new Promise((resolve) => {
      chrome.identity.getAuthToken({ interactive: false }, (token) => {
        if (token) {
          chrome.identity.removeCachedAuthToken({ token }, resolve);
        } else {
          resolve();
        }
      });
    });
  }

  // ── API helper ──────────────────────────────────────────────────────────────
  async function api(method, url, body, token) {
    const opts = {
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(url, opts);
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `HTTP ${res.status}`);
    }
    return res.json();
  }

  // ── Sheet helpers ───────────────────────────────────────────────────────────

  // Return list of sheet (tab) titles in the spreadsheet
  async function getSheetTitles(spreadsheetId, token) {
    const data = await api('GET',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties`,
      null, token);
    return data.sheets.map(s => s.properties.title);
  }

  // Create a new tab (sheet) in the spreadsheet
  async function addSheet(spreadsheetId, title, token) {
    await api('POST',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`,
      { requests: [{ addSheet: { properties: { title } } }] },
      token);
  }

  // Append header row to a brand-new sheet
  async function writeHeader(spreadsheetId, sheetTitle, token) {
    // Column order: A–L matching user's spreadsheet exactly
    const HEADERS = [
      'placeUrl',       // A
      'title',          // B
      'rating',         // C
      'reviewCount',    // D
      'category',       // E
      'address',        // F
      'plusCode',       // G
      'website',        // H
      'phoneNumber',    // I
      'currentStatus',  // J
      'scrapedAt',      // K
      'importedAt',     // L
    ];
    await api('POST',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle + '!A1')}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
      { values: [HEADERS] },
      token);
  }

  // Fetch ALL phone numbers already in the sheet to check duplicates
  // Also fetches from the Master sheet
  async function getAllKnownPhones(spreadsheetId, token) {
    const titles = await getSheetTitles(spreadsheetId, token);
    const phones = new Set();

    for (const title of titles) {
      try {
        // Phone is column I (index 8) — phoneNumber
        const data = await api('GET',
          `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(title + '!I2:I')}`,
          null, token);
        const rows = data.values || [];
        rows.forEach(row => {
          const raw = (row[0] || '').toString().trim();
          const norm = normalizePhone(raw);
          if (norm) phones.add(norm);
        });
      } catch (_) { /* sheet may be empty or inaccessible */ }
    }
    return phones;
  }

  // Normalize phone to digits only for comparison
  function normalizePhone(phone) {
    if (!phone) return '';
    return phone.replace(/\D/g, '');
  }

  // ── Session sheet name ──────────────────────────────────────────────────────
  function sessionSheetName() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const h = String(now.getHours()).padStart(2, '0');
    const min = String(now.getMinutes()).padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}`;
  }

  // Convert a lead object to a sheet row array — columns A–L
  function leadToRow(lead) {
    const now = new Date().toISOString();
    return [
      lead.placeUrl      || (lead.place_id ? `https://www.google.com/maps/place/?q=place_id:${lead.place_id}` : ''),  // A placeUrl
      lead.name          || '',   // B title
      lead.rating        || '',   // C rating
      lead.reviewCount   || '',   // D reviewCount
      lead.category      || '',   // E category
      lead.address       || '',   // F address
      lead.plusCode      || '',   // G plusCode
      lead.website       || '',   // H website
      lead.phone         || '',   // I phoneNumber
      lead.currentStatus || '',   // J currentStatus
      lead.scraped_at    || now,  // K scrapedAt
      now,                        // L importedAt (time of this import)
    ];
  }

  // ── Ensure "Master" sheet exists ────────────────────────────────────────────
  async function ensureMasterSheet(spreadsheetId, token) {
    const titles = await getSheetTitles(spreadsheetId, token);
    if (!titles.includes('Master')) {
      await addSheet(spreadsheetId, 'Master', token);
      await writeHeader(spreadsheetId, 'Master', token);
    }
    return titles;
  }

  // ── Main export function ────────────────────────────────────────────────────
  // Returns { imported, duplicates, sheetName }
  async function exportToSheets(leads, spreadsheetId) {
    if (!leads.length) throw new Error('No leads to export.');
    if (!spreadsheetId) throw new Error('No Spreadsheet ID configured. Open Settings to add one.');

    const token = await getToken(true);

    // 1. Gather all known phones across the entire spreadsheet
    const knownPhones = await getAllKnownPhones(spreadsheetId, token);

    // 2. Classify leads
    const toImport = [];
    const dupes = [];

    for (const lead of leads) {
      const norm = normalizePhone(lead.phone);
      if (norm && knownPhones.has(norm)) {
        dupes.push(lead);
      } else {
        toImport.push(lead);
        if (norm) knownPhones.add(norm); // prevent intra-batch dupes too
      }
    }

    return { toImport, dupes, token, spreadsheetId };
  }

  // ── Commit the import (called after user confirms) ──────────────────────────
  async function commitImport(toImport, spreadsheetId, token) {
    if (!toImport.length) return { imported: 0, sheetName: '' };

    const sessionLabel = sessionSheetName();

    // Ensure Master sheet exists; get all titles
    const titles = await ensureMasterSheet(spreadsheetId, token);

    // Create session sheet
    await addSheet(spreadsheetId, sessionLabel, token);
    await writeHeader(spreadsheetId, sessionLabel, token);

    const rows = toImport.map(l => leadToRow(l));

    // Write to session sheet
    await api('POST',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sessionLabel + '!A2')}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
      { values: rows },
      token);

    // Write to Master sheet
    await api('POST',
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent('Master!A2')}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
      { values: rows },
      token);

    // Auto-resize columns on session sheet (best-effort)
    try {
      const meta = await api('GET',
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties`,
        null, token);
      const sheet = meta.sheets.find(s => s.properties.title === sessionLabel);
      if (sheet) {
        const sheetId = sheet.properties.sheetId;
        await api('POST',
          `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}:batchUpdate`,
          {
            requests: [{
              autoResizeDimensions: {
                dimensions: { sheetId, dimension: 'COLUMNS', startIndex: 0, endIndex: 13 }
              }
            }]
          },
          token);
      }
    } catch (_) { /* non-critical */ }

    return { imported: toImport.length, sheetName: sessionLabel };
  }

  // ── Validate a spreadsheet ID ───────────────────────────────────────────────
  async function validateSpreadsheet(spreadsheetId) {
    try {
      const token = await getToken(true);
      const data = await api('GET',
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=properties.title`,
        null, token);
      return { valid: true, title: data.properties?.title || spreadsheetId };
    } catch (e) {
      return { valid: false, error: e.message };
    }
  }

  return { exportToSheets, commitImport, validateSpreadsheet, revokeToken };
})();
