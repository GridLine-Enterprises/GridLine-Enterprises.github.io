// Google Maps Scraper Pro - Content Script v3
// Strategy: click each result card → wait for detail panel → scrape phone/website/address → next card
(function () {
  'use strict';

  let scraping = false;
  let processedPlaces = new Set();
  let seenWebsites = new Set();   // tracks websites already claimed by a previous lead
  let scrapeLoop = null;
  let scrapeLimit = 0; // 0 = unlimited

  const SOCIAL_DOMAINS = [
    'facebook.com','fb.com','instagram.com','twitter.com','x.com',
    'linkedin.com','tiktok.com','youtube.com','pinterest.com',
    'snapchat.com','yelp.com','tripadvisor.com','nextdoor.com',
    'linktr.ee','linktree.com','beacons.ai','bio.link',
    'google.com','maps.google.com','business.google.com'
  ];

  function websiteType(url) {
    if (!url) return 'none';
    try {
      const host = new URL(url).hostname.replace(/^www\./, '');
      if (SOCIAL_DOMAINS.some(d => host === d || host.endsWith('.' + d))) return 'social';
    } catch {}
    return 'real';
  }

  // ─── Inject XHR/fetch interceptor ───────────────────────────────────────────
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('injected.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);

  // ─── Main scrape loop: click each card, wait for panel, extract, next ────────
  async function runScrapeLoop() {
    // Get the scrollable results feed
    const feed = await waitFor(() => document.querySelector('[role="feed"]'), 8000);
    if (!feed) { setStatus('Could not find results list.'); return; }

    let processedCards = new Set();

    while (scraping) {
      // Get all visible cards
      const cards = [...feed.querySelectorAll('.Nv2PK')];

      // Find next unprocessed card
      let nextCard = null;
      for (const card of cards) {
        const nameEl = card.querySelector('.qBF1Pd, .fontHeadlineSmall');
        const cardName = nameEl?.textContent?.trim();
        if (cardName && !processedCards.has(cardName)) {
          nextCard = card;
          break;
        }
      }

      if (!nextCard) {
        // Try scrolling to load more
        feed.scrollBy(0, 600);
        await sleep(2000);

        const newCards = [...feed.querySelectorAll('.Nv2PK')];
        const allProcessed = newCards.every(card => {
          const n = card.querySelector('.qBF1Pd, .fontHeadlineSmall')?.textContent?.trim();
          return !n || processedCards.has(n);
        });

        if (allProcessed) {
          // Truly at the end
          chrome.runtime.sendMessage({ type: 'SCROLL_DONE' });
          break;
        }
        continue;
      }

      // Mark as processing
      const cardName = nextCard.querySelector('.qBF1Pd, .fontHeadlineSmall')?.textContent?.trim();
      processedCards.add(cardName);

      // Scroll card into view and click it
      nextCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(400);

      // Use a real MouseEvent so Google Maps' listeners fire correctly
      const clickTarget = nextCard.querySelector('a') || nextCard;
      clickTarget.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      await sleep(50);
      clickTarget.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true, view: window }));
      clickTarget.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true, view: window }));

      // Wait for the detail panel to load with THIS business's name
      const panelLoaded = await waitFor(() => {
        const h1 = document.querySelector('h1.DUwDvf, h1.fontHeadlineLarge');
        return h1 && h1.textContent.trim() === cardName;
      }, 6000);

      if (!panelLoaded) { await sleep(500); continue; }

      // Wait a bit more for phone/website to render
      await sleep(800);

      // Scrape the full detail panel
      const lead = scrapeDetailPanel();
      if (lead && lead.name && !processedPlaces.has(lead.name)) {
        processedPlaces.add(lead.name);
        // Blank out website if already claimed by a previous lead
        if (lead.website) {
          const normalised = lead.website.toLowerCase().replace(/\/$/, '');
          if (seenWebsites.has(normalised)) {
            lead.website = '';
            lead.website_type = 'none';
          } else {
            seenWebsites.add(normalised);
          }
        }
        chrome.runtime.sendMessage({ type: 'ADD_LEAD', lead });
        // Check limit
        if (scrapeLimit > 0 && processedPlaces.size >= scrapeLimit) {
          scraping = false;
          chrome.runtime.sendMessage({ type: 'LIMIT_REACHED' });
          break;
        }
      }

      await sleep(400);
    }
  }

  // ─── Scrape the open detail panel for ALL fields ─────────────────────────────
  function scrapeDetailPanel() {
    const name = document.querySelector('h1.DUwDvf, h1.fontHeadlineLarge')?.textContent?.trim();
    if (!name) return null;

    // ── Phone ──
    // Try every possible selector Google Maps uses for phone
    let phone = '';
    const phoneAttempts = [
      // data-item-id with "phone" substring
      () => {
        const els = document.querySelectorAll('[data-item-id]');
        for (const el of els) {
          if (el.dataset.itemId && el.dataset.itemId.includes('phone')) {
            const txt = el.querySelector('.Io6YTe, .rogA2c')?.textContent?.trim();
            if (txt && isPhone(txt)) return txt;
          }
        }
      },
      // tel: href links
      () => {
        const a = document.querySelector('a[href^="tel:"]');
        if (a) return decodeURIComponent(a.href.replace('tel:', ''));
      },
      // aria-label containing "phone"
      () => {
        const els = document.querySelectorAll('[aria-label]');
        for (const el of els) {
          if (el.getAttribute('aria-label')?.toLowerCase().includes('phone')) {
            const txt = el.querySelector('.Io6YTe, .rogA2c')?.textContent?.trim()
                     || el.textContent?.trim();
            if (txt && isPhone(txt)) return txt;
          }
        }
      },
      // Scan ALL .Io6YTe elements for phone-like text
      () => {
        for (const el of document.querySelectorAll('.Io6YTe, .rogA2c')) {
          const txt = el.textContent?.trim();
          if (txt && isPhone(txt)) return txt;
        }
      },
      // Scan all text nodes as last resort
      () => {
        const walker = document.createTreeWalker(
          document.querySelector('.m6QErb, [role="main"]') || document.body,
          NodeFilter.SHOW_TEXT
        );
        let node;
        while ((node = walker.nextNode())) {
          const txt = node.textContent?.trim();
          if (txt && isPhone(txt)) return txt;
        }
      },
    ];

    for (const attempt of phoneAttempts) {
      try {
        const result = attempt();
        if (result && isPhone(result)) { phone = result; break; }
      } catch {}
    }

    // ── Website ──
    let website = '';
    const webAttempts = [
      () => {
        const els = document.querySelectorAll('[data-item-id]');
        for (const el of els) {
          if (el.dataset.itemId?.includes('authority')) {
            const a = el.querySelector('a[href]') || (el.tagName === 'A' ? el : null);
            if (a?.href && isWebsite(a.href)) return a.href;
          }
        }
      },
      () => {
        for (const sel of ['a[data-item-id*="authority"]', 'a[aria-label*="website" i]', '[aria-label*="website" i] a']) {
          const el = document.querySelector(sel);
          if (el?.href && isWebsite(el.href)) return el.href;
        }
      },
    ];
    for (const attempt of webAttempts) {
      try { const r = attempt(); if (r) { website = r; break; } } catch {}
    }

    // ── Address ──
    let address = '';
    const addrAttempts = [
      () => {
        const els = document.querySelectorAll('[data-item-id]');
        for (const el of els) {
          if (el.dataset.itemId?.includes('address')) {
            const txt = el.querySelector('.Io6YTe, .rogA2c')?.textContent?.trim();
            if (txt && isStrictAddress(txt)) return txt;
          }
        }
      },
      () => {
        for (const sel of ['[aria-label*="address" i] .Io6YTe', 'button[aria-label*="address" i] .rogA2c']) {
          const el = document.querySelector(sel);
          if (el?.textContent?.trim()) return el.textContent.trim();
        }
      },
      () => {
        for (const el of document.querySelectorAll('.Io6YTe, .rogA2c')) {
          const txt = el.textContent?.trim();
          if (txt && isStrictAddress(txt) && !isPhone(txt)) return txt;
        }
      },
    ];
    for (const attempt of addrAttempts) {
      try { const r = attempt(); if (r) { address = r; break; } } catch {}
    }

    // ── Rating & review count ──
    const rating = document.querySelector('.F7nice span[aria-hidden="true"]')?.textContent?.trim() || '';
    // Pull just the digit count from aria-label e.g. "4.9 stars 487 reviews" → "487"
    const reviewsRaw = document.querySelector('.F7nice span[aria-label]')?.getAttribute('aria-label') || '';
    const reviewCountMatch = reviewsRaw.match(/[\d,]+/g);
    const reviewCount = reviewCountMatch ? reviewCountMatch.filter(n => n.replace(/,/g,'')).pop()?.replace(/,/g,'') || '' : '';

    // ── Category ──
    const category = document.querySelector('.DkEaL')?.textContent?.trim()
                  || document.querySelector('.mgr77e button')?.textContent?.trim() || '';

    // ── Place URL — snapshot the live URL while the panel is open ──
    // location.href at this point is already the canonical shareable Maps URL
    const placeUrl = location.href.split('?')[0]; // strip any query noise, keep the path

    // ── Place ID — extract the 0x... hex ID from the URL ──
    const place_id = location.href.match(/!1s(0x[0-9a-fA-F]+:[0-9a-fA-F]+)/)?.[1]
                  || location.href.match(/place\/[^\/]+\/@[^\/]+\/([^\/\?#]+)/)?.[1] || '';

    // ── Plus Code ──
    let plusCode = '';
    for (const el of document.querySelectorAll('[data-item-id]')) {
      if (el.dataset.itemId?.includes('oloc')) {
        plusCode = el.querySelector('.Io6YTe, .rogA2c')?.textContent?.trim() || '';
        if (plusCode) break;
      }
    }
    if (!plusCode) {
      for (const el of document.querySelectorAll('.Io6YTe, .rogA2c')) {
        const t = el.textContent?.trim();
        if (t && /^[A-Z0-9]{4,6}\+[A-Z0-9]{2,}/.test(t)) { plusCode = t; break; }
      }
    }

    // ── Current Status (open/closed) ──
    const currentStatus = document.querySelector('.o0Svhf, .ZDu9vd, .WkFtFd')?.textContent?.trim() || '';

    // ── Info / description ──
    const info = document.querySelector('.PYvSYb, .HlvSq')?.textContent?.trim() || '';

    // ── Image URL ──
    const imgEl = document.querySelector('button[jsaction*="pane.heroHeaderImage"] img, .ZKCDEc img');
    const imgUrl = imgEl?.src || '';

    // ── Attributes — scrape the About tab sections (Accessibility, Service options, Highlights, etc.) ──
    // These live in attribute blocks with a heading + checkmarked items
    let attributes = '';
    try {
      const attrSections = [];
      // Each section has a heading (.iP2t7d or similar) + list of items (.hpLkke span or .aSK4jb)
      const sectionEls = document.querySelectorAll('.iP2t7d, [jslog*="about"] .iP2t7d, .LTs0Rc');
      if (sectionEls.length) {
        sectionEls.forEach(sec => {
          const heading = sec.querySelector('.fontTitleSmall, .iP2t7d')?.textContent?.trim()
                       || sec.textContent?.split('\n')[0]?.trim();
          const items = [...sec.querySelectorAll('.hpLkke span:not(.A2a7V), .KFi3Cc, .aSK4jb')]
            .map(el => el.textContent?.trim()).filter(Boolean);
          if (heading && items.length) attrSections.push(`${heading}: ${items.join(', ')}`);
          else if (items.length) attrSections.push(items.join(', '));
        });
      }
      // Fallback: grab all attribute chip-style labels
      if (!attrSections.length) {
        document.querySelectorAll('.RcCsl .hpLkke, .mkzdOd').forEach(el => {
          const t = el.textContent?.trim();
          if (t) attrSections.push(t);
        });
      }
      attributes = attrSections.join(' | ');
    } catch {}

    return { name, phone, website, website_type: websiteType(website), address, rating, reviewCount, category, place_id, placeUrl, plusCode, currentStatus };
  }

  // ─── Validators ──────────────────────────────────────────────────────────────
  function isPhone(v) {
    if (typeof v !== 'string') return false;
    const s = v.trim();
    // Must start with +, (, or digit
    if (!/^[\+\(\d]/.test(s)) return false;
    // Count digits
    const digits = s.replace(/\D/g, '');
    if (digits.length < 7 || digits.length > 15) return false;
    // Must not be a rating or zip-only
    if (/^\d{4,5}$/.test(s)) return false;
    // Allow standard phone characters only
    return /^[\+\d\s\-\(\)\.]{7,20}$/.test(s);
  }

  function isWebsite(v) {
    if (typeof v !== 'string') return false;
    if (!/^https?:\/\/.+\..+/.test(v)) return false;
    try {
      const host = new URL(v).hostname.replace(/^www\./, '');
      if (host === 'google.com' || host.endsWith('.google.com')) return false;
    } catch {}
    return !v.includes('goo.gl');
  }

  function isStrictAddress(v) {
    if (typeof v !== 'string') return false;
    const s = v.trim();
    if (/^\d+\.?\d*$/.test(s)) return false;
    if (!/\d/.test(s) || !/[A-Za-z]/.test(s)) return false;
    if (s.length < 6 || s.length > 200) return false;
    if (isPhone(s) || s.startsWith('http')) return false;
    return s.split(/\s+/).length >= 2;
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────────
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function waitFor(fn, timeout = 5000) {
    return new Promise(resolve => {
      const start = Date.now();
      const check = () => {
        const result = fn();
        if (result) return resolve(result);
        if (Date.now() - start > timeout) return resolve(null);
        setTimeout(check, 200);
      };
      check();
    });
  }

  function setStatus(msg) {
    chrome.runtime.sendMessage({ type: 'STATUS_MSG', msg });
  }

  // ─── Message listener ─────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (msg.type === 'START_SCRAPING') {
      scraping = true;
      scrapeLimit = msg.limit || 0;
      processedPlaces.clear();
      seenWebsites.clear();
      runScrapeLoop();
      respond({ success: true });
    }
    if (msg.type === 'STOP_SCRAPING') {
      scraping = false;
      respond({ success: true });
    }
    if (msg.type === 'SCRAPE_NOW') {
      const lead = scrapeDetailPanel();
      if (lead?.name && !processedPlaces.has(lead.name)) {
        processedPlaces.add(lead.name);
        if (lead.website) {
          const normalised = lead.website.toLowerCase().replace(/\/$/, '');
          if (seenWebsites.has(normalised)) {
            lead.website = '';
            lead.website_type = 'none';
          } else {
            seenWebsites.add(normalised);
          }
        }
        chrome.runtime.sendMessage({ type: 'ADD_LEAD', lead });
      }
      respond({ success: true });
    }
    return true;
  });

})();
