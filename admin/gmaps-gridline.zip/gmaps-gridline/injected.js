// Injected into page context to intercept Google Maps XHR/fetch responses
(function () {
  'use strict';

  const DISPATCH = (data) => {
    window.dispatchEvent(new CustomEvent('GMAPS_SCRAPER_DATA', { detail: data }));
  };

  // ── Intercept XMLHttpRequest ─────────────────────────────────────────────────
  const OrigXHR = window.XMLHttpRequest;
  function PatchedXHR() {
    const xhr = new OrigXHR();
    const proxy = this;

    xhr.addEventListener('readystatechange', function () {
      if (xhr.readyState === 4 && xhr.status === 200) {
        const url = xhr.responseURL || '';
        if (url.includes('/search') || url.includes('maps/search') || url.includes('place/') || url.includes('listugcposts') || url.includes('viewportid')) {
          try { DISPATCH(xhr.responseText); } catch (e) {}
        }
      }
    });

    // Proxy all properties
    return new Proxy(proxy, {
      get(t, prop) {
        if (prop in xhr) {
          const val = xhr[prop];
          return typeof val === 'function' ? val.bind(xhr) : val;
        }
        return t[prop];
      },
      set(t, prop, val) {
        try { xhr[prop] = val; } catch (e) { t[prop] = val; }
        return true;
      }
    });
  }
  PatchedXHR.prototype = OrigXHR.prototype;
  Object.assign(PatchedXHR, OrigXHR);
  window.XMLHttpRequest = PatchedXHR;

  // ── Intercept fetch ──────────────────────────────────────────────────────────
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    try {
      const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
      if (url.includes('/search') || url.includes('maps/search') || url.includes('place/') || url.includes('listugcposts')) {
        const clone = response.clone();
        clone.text().then(text => {
          try { DISPATCH(text); } catch (e) {}
        }).catch(() => {});
      }
    } catch (e) {}
    return response;
  };

  console.log('[GMaps Scraper Pro] Interceptor active');
})();
